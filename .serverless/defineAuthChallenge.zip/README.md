# ez-stack-authentication

serverless repository for the one time password authentication flow for ez-stack project
